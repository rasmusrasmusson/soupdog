export default function Page() {
  return (
    <div className="p-8">
      <span className="font-mono text-[11px] text-[var(--muted)] uppercase tracking-widest">History — coming soon</span>
    </div>
  );
}
