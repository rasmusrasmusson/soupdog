# Soupdog — Create-a-Recipe Front Door Design v0.1

**Status:** design-settled, pre-build. The user-facing entry point for creating a
recipe — single dish OR meal — that drives the already-built-and-proven backend
(decompose engine → decompose-save → multi-dish display, all green as of
2026-06-26). This doc settles the IA and the per-dish resolution flow; the backend
it feeds is done. Grounded in a live trace of `src/app/my/recipes/import/page.tsx`
(983 lines) and `src/app/api/recipes/generate/route.ts` (196 lines).

---

## 0. What this is, and what already exists

The backend is built: a meal decomposes into one unified DAG (shared prep merged,
one terminal per dish, existing dishes LINKED via `resolvedDishes` → emitted as
`linkedDishes` → persisted as `version_sub_recipes` → rendered as "Dishes in this
meal"). What's missing is the **front door**: the UI + flow that lets a user
express what they want and PRODUCES the `resolvedDishes` the engine already honours.

Already in the codebase (the foundation, not throwaway):
- `/api/recipes/import` — parse pasted text / uploaded file → rough extraction.
- `/api/recipes/decompose` — extraction (+ optional `resolvedDishes`) → DAG. PROVEN.
- `/api/recipes/decompose-save` — DAG → persisted recipe (meal-aware). PROVEN.
- `/api/recipes/generate` — takes a prompt + the user's catalogue (titles), an
  internal model call decides one of: **clarify / existing / generate**. The
  "existing" branch ALREADY searches the user's own recipes and returns links. This
  is 80% of per-dish search — but built around a SINGLE dish.

The build extends this single-recipe foundation to "one or many dishes," without
ever asking the user to categorise.

---

## 1. Language rules (non-negotiable, applies to ALL copy)

- **Never say "AI"** in user-facing copy. AI is invisible plumbing (per standing
  monetisation design — "like bragging about electric lights"). Frame by OUTCOME.
- **Never say "butler"** — that is an INTERNAL concept name only.
- Verbs, not mechanisms: "Describe what you want", "Create", "Add a dish",
  "Generate a photo" — never "ask the assistant", "the AI will…", "parse".
- This is partly CLEANUP: the current page has internal "Create-with-AI" /
  butler-flavoured copy → relabel.

---

## 2. The IA — two sections + an add-dish affordance

Collapse today's three-ish entry points (paste text / upload file / generate
prompt) into TWO clear sections, plus one button:

```
Create a recipe
├─ (1) Describe what you want      [free text box]
├─ (2) Upload                       [ONE box: image / text / file — drop, paste, or attach]
└─ [+ Add another dish]             (appears once there is ≥1 dish; turns it into a meal,
                                      naturally, without ever asking "is this a meal?")
```

- **(1) Describe** — the fast path. Free text of what they want made
  ("a quick weeknight dhal"; "a dinner with carbonara, a green salad, and iced tea").
- **(2) Upload** — ONE unified box accepting image OR text OR file (photo of a recipe
  card, pasted text, attached .docx/.xlsx/.pdf). All flow to the existing parse path
  (`/api/recipes/import`), which already handles these. (Merging the currently-separate
  paste-vs-upload controls into one box is a UI change, not a backend one.)
- **[+ Add another dish]** — the explicit/builder path: start with one dish, add more.
  Its mere existence is how multi-dish happens — no toggle, no mode.

---

## 3. KEY DECISION — the system infers dish count; the user never declares it

A "meal" is a subjective view, not a type (standing principle). So:
- The user NEVER answers "is this one dish or a meal?"
- **Single vs multi is inferred** from what is described/added:
  - "Make me a carbonara" → one dish.
  - "A dinner with carbonara, salad, and iced tea" → three dishes (the model splits).
  - Two dishes added via [+ Add another dish] → two dishes.
- Single-dish is simply the **n = 1** case of the same flow. There is ONE flow, not a
  single-recipe flow and a separate meal flow.

Two paths into multi-dish, both supported:
- **Describe-splits** (fast): one sentence naming several dishes → the model
  identifies the dish list.
- **Add-another-dish** (explicit): each dish entered separately → already split.

---

## 4. Per-dish resolution — link-or-make (reuse decided by search + user)

For EACH dish (however it arrived), the same resolution, reusing the standing
principle "reuse is decided by search + user disambiguation, not silently by AI":

1. **Search** the user's catalogue for that dish (extends the `generate` "existing"
   title-match logic, applied per dish).
2. **Single clear match** → auto-LINK it (becomes a `resolvedDishes` entry → the
   engine links it, does not re-decompose). 
3. **Multiple matches** → ASK the user to pick (disambiguation). [DEFERRED to Slice 2
   — see §6; Slice 1 picks best/most-recent or makes fresh.]
4. **No match** → MAKE it fresh (generate text if described-only, or use the
   uploaded/parsed text) → decompose inline as part of the unified meal DAG.

The resolved links + the fresh dishes both feed the proven pipeline:
`resolvedDishes` + extraction → `/api/recipes/decompose` → `/api/recipes/decompose-save`.

---

## 5. Architecture — extend the existing flow (not a parallel one)

Lean: **extend `/api/recipes/generate`** with a `meal` outcome rather than building a
separate multi-dish endpoint. The butler-internal endpoint already loads the
catalogue, calls the model to decide, matches titles, and returns links — the meal
case is "do that, but per dish." Reusing it keeps ONE front door.

- Add a fourth action: `{action:'meal', dishes:[{name, ...}]}` — the model identifies
  the dish list from the request.
- Per-dish catalogue matching reuses the existing normalised-title match logic
  (currently single-dish) in a loop.
- Output: for each dish, either a resolved link (catalogue hit) or a to-make marker.
- The client assembles `resolvedDishes` (links) + drives generation/parse for the
  to-make dishes, then calls decompose with both.

(Single-dish requests still resolve to the existing clarify/existing/generate
outcomes — the `meal` action only fires when >1 dish is identified. n=1 is unchanged.)

---

## 6. Build slices (incremental — prove the front door, then refine)

- **Slice 1 (this build):** the two-section IA (Describe / Upload, unified upload box)
  + [+ Add another dish]; infer dish count; per-dish auto-link of a SINGLE clear match,
  else make fresh; compose through the proven engine. NO disambiguation picker
  (multiple matches → pick best/most-recent or make fresh). NO photo generation.
  Relabel all copy per §1.
  → Proves the whole front door end to end: "a meal with aglio e olio and a salad"
    reuses the existing aglio e olio + makes the salad, into one rendered meal.
- **Slice 2:** the disambiguation picker — multiple catalogue matches → interactive
  choose-which (the fiddliest UI; isolated on purpose).
- **Slice 3 (separate capability):** "Generate a photo" — image generation for a
  dish/recipe. NEW capability (image model + cost + storage); seam named in the
  Upload section, NOT built now.

---

## 7. Deferred / seams named (don't build yet)

- **Disambiguation picker** (Slice 2) — multiple matches → user picks.
- **Generate-a-photo** (Slice 3) — image-gen; the Upload box hosts the affordance
  but the capability is its own slice (model, cost, storage).
- **Linking OTHER users' published dishes** into a meal — the `version_sub_recipes`
  write policy already permits it (gates on owning the PARENT meal), but Slice 1
  searches only the user's OWN catalogue (as `generate` does today). Public-recipe
  reuse is a later widening.
- **Promotion** of an embedded fresh dish → standalone recipe — separate gated
  pipeline (from the composition consolidation doc), unaffected here.

---

## 8. [OPEN] decisions to settle while building Slice 1

1. When Describe names several dishes AND some are uploaded/added separately, how do
   the two paths merge into one dish list? (Likely: a single in-page list of dishes,
   each tagged by how it arrived; Describe-split pre-populates it.)
2. Single-dish requests: keep the exact current clarify/existing/generate UX, or fold
   them into the same per-dish list with n=1? (Lean: fold, so there is truly one flow.)
3. "Pick best" rule for Slice-1 multiple-match (most recent? highest-version?
   published-over-draft?) — provisional; the real answer is Slice 2's picker.
4. Where the dish list lives in state on the import page (new state shape) and how it
   threads into the existing `handleImportFile` → decompose → save path.

Settle 1–4 inline during the Slice-1 build; none are spine-level.

---

## 9. BUILD STATUS (2026-06-26) — Slice 1 backend proven

### DONE — the `meal` action in /api/recipes/generate (proven live)
`generate` now has a fourth action **meal**: the model identifies multiple dishes from
one request; the route resolves EACH against the user's catalogue (reusing the
existing `norm` title-match) → returns `{ meal: { dishes: [{ name, status:'linked'|'make',
canonicalId?, canonicalSlug?, title?, otherMatchCount? }] } }`. Single-dish requests
still go to clarify/existing/generate unchanged; `meal` only fires for >1 dish.
Slice-1 "pick best" on multiple matches = exact-title > published > first;
`otherMatchCount` surfaced as the hook for Slice 2's picker.
VERIFIED live: "a dinner with spaghetti aglio e olio and a green salad" →
aglio e olio `linked` (correct canonical), green salad `make`. Per-dish link-vs-make works.

### REMAINING in Slice 1 — the page (the bigger, iterative half)
The import page (`src/app/my/recipes/import/page.tsx`, ~983 lines) must:
1. two sections (Describe / Upload unified box) + [+ Add another dish], relabeled (§1).
2. a dish-list state (each dish: how it arrived + linked/make status).
3. Describe → generate → branch (clarify/existing/generate single, OR meal → populate list).
4. ASSEMBLY (the risky new part): for `make` dishes generate/parse text; combine with
   `linked` dishes as `resolvedDishes`; ONE decompose → save through the proven pipeline.

### DECISION for the page build — two ways to do Slice 1:
- **(1a) full IA rebuild** — two-section redesign + dish list + add-dish, all at once.
  Faithful but a big single change to a long file, high click-through to verify.
- **(1b) minimal meal path first** — keep the page mostly as-is; when generate returns
  `meal`, run the ASSEMBLY (generate make-dishes → build resolvedDishes → decompose →
  save) and show the multi-dish preview. Proves the end-to-end meal pipeline THROUGH the
  UI (the riskiest, most valuable thing) without the layout churn. IA polish = follow-up.

**Lean: (1b) — prove meal assembly first, redesign IA second.** The assembly is the
risky new logic and the real proof the front door works; the IA is lower-risk, high-churn
layout. Splitting verifies the hard part before investing in layout — matches the
session's prove-the-mechanism-then-build-the-surface pattern. Best started FRESH (heaviest,
most iterative build of the feature).

---

## 10. (1a) CREATE-FLOW REBUILD — design captured (NOT built; next deliberate build)

Surfaced by testing Slice-1 (1b) live: the current preview is interim scaffolding. It
behaves like an empty FORM the user fills (title/cuisine/difficulty/tags/servings), which
is BACKWARDS when the system built the recipe — the user shouldn't teach the system the
difficulty of its own output. The real create flow is two screens with clear ownership:

### Screen 1 — INPUT (gather intent, including WHO'S EATING)
- (1) Describe what you want + (2) Upload (image/text/file) + [+ Add another dish] — §2.
- **NEW: a "who's eating" control here, BEFORE generation**, because who it's for should
  SHAPE what's made (quantities, portions) — not be tweaked afterward on the preview.
- **DEFAULT = generic personas, not real people.** Critical: the COMMON case (esp. for
  Soupdog content creators) is authoring a GENERIC recipe FIRST — a standard-serving,
  serving-size-agnostic canonical. Specific serving sizes / real people come LATER as
  VARIATIONS (ties to existing `execution_variants` + the demand/plating model). So:
  - The generic path is the frictionless DEFAULT (e.g. "serves 2/4", generic eaters).
  - Personas must be EASILY ACCESSIBLE (quick to pick) but NEVER mandatory.
  - Picking real people/specific sizes is available but is the *variation* layer, not the
    base-authoring default.

### Screen 2 — PREVIEW = REVIEW THE MADE RECIPE (not a form to fill)
- **Show the CREATED recipe in full** (reuse `RecipeDisplay`) — including linked dishes.
  Today the pure-link preview shows only meta + a components line, not the dishes; the
  preview must render the actual composed meal so the user confirms real content.
- Fields arrive **POPULATED by the system** (cuisine, difficulty, tags, description
  inferred from the dishes) — user may edit, but it's REVIEW not data-entry.
- Title = menu-style default (done, §9/§ title work), editable.
- Footer copy: "review and save" — NOT "review the steps" (wrong for pure-link meals).

### Servings / who's-eating — depth
- **Shallow (build with 1a):** the who's-eating control sets the meal's servings (a generic
  persona count by default; resolves to a number).
- **Deep (NAMED SEAM, not now):** that choice actually SHAPES generation — quantities
  scaled, per-person portions via the already-built demand/plating model. Connects creation
  to the demand model; its own feature. Generic-first authoring means the base recipe is
  made generically and the deep per-person shaping is a VARIATION, not the base.

### Also folded into 1a (from §1)
- Relabel all copy: no "AI", no "butler" ("Create with AI" / "Ask the AI" → outcome verbs).
- Two-section IA + [+ Add another dish] (§2) — still pending; current page is interim.

### Status
Slice-1 (1b) PROVED the pipeline end to end (describe → meal → link/make → save → display),
incl. pure-link meals (§ pure-link work). The (1a) rebuild above is the proper create UX:
input gathers intent + who's-eating (generic-persona default); preview reviews a fully-shown
result with system-populated fields. Build deliberately as its own session. Deep
generation-shaping by who's-eating = named seam, downstream of wiring the demand model into
creation.

---

## 11. #3 DONE (preview shows the made recipe) + new findings from live testing

### #3 shipped & proven (all three meal shapes)
`dagToRecipe` now maps `dag.linkedDishes → recipe.subRecipes`, so the preview renders
the made recipe INCLUDING linked dishes (was empty for pure-link). Verified live:
- pure-link (two existing dishes) → preview + saved page show both under "Dishes in this
  meal"; saved page expands them fully.
- mixed, one new dish made inline + existing dishes linked (beer; lemon water) → new dish
  decomposed inline (ingredients/tools/steps), existing dishes linked. Menu titles correct
  ("… with Green Salad, and beer" / "… and lemon water").

### NEW FINDING — "served, not made" dishes (→ recipe.kind seam)
Test (c) added "beer". The flow tried to GENERATE A RECIPE for it → "No recipe details
could be generated" + a stub step "Add beer → Serve beer as desired". Beer isn't a recipe —
it's poured/served. Some meal components are SERVED, not MADE (beer, wine, a bought bottle,
store bread). They should NOT be force-fit through recipe generation.
→ This is the `recipe.kind` distinction from the earlier design docs
(composed / simple / acquire / **none**). A "none"/"acquire" component = no method, just
served. CREATE FLOW must detect these (the meal-resolution step, or generate) and represent
them as served-components, not generate an awkward stub. NAMED SEAM — downstream of wiring
recipe.kind; do not patch the stub now. (Folds into 1a's per-dish handling.)

### Confirmed interim (all 1a, as already banked §10)
The arbitrary "Serves 4/1", empty form fields, "Review the steps" + "Create with AI" copy,
and the beer stub are all the interim create-flow scaffolding. 1a rebuild fixes: review-not-
form, system-populated fields, who's-eating up front (generic-persona default), relabel,
and served-not-made components.

---

## 12. SERVED-NOT-MADE is now causing COMPOSE FAILURES (was UX, now a bug) — next design piece

Live testing (hamburger+fries+**coke**; cobb salad + **homemade lemonade**) surfaced that
the served-not-made / from-scratch problem is no longer just awkward — it BREAKS compose.

### Symptoms
- **Coke dropped:** "hamburger, fries, coke" → coke listed WILL BE MADE, but the composed
  recipe (saved + PDF) has burger + fries, NO coke. The generate/parse couldn't make a
  Coca-Cola recipe → it vanished.
- **Incomplete structure error:** "cobb salad with homemade lemonade" → compose → parse
  returned a structure missing title/ingredients/groups → `import/route.ts:223`
  "Incomplete recipe structure returned" → whole compose failed.

### Diagnosis — same root cause as the served-not-made seam
The system has NO concept of "served, not made," so it pushes un-makeable / trivially-
served items (Coke) and degenerate-to-make items through recipe GENERATION + PARSE. That
output is either dropped (coke) or breaks the parser's structure validation (lemonade).
Real cookable dishes (burger, fries, katsu, salad) work fine. So the bug correlates with
dish KIND — it IS the recipe.kind gap manifesting as compose failure.

### The design (the proper fix — recipe.kind: composed/simple/acquire/none)
1. **Detect served-not-made** at the meal-resolution step (or generate): Coke, beer, wine,
   bought bread = `acquire`/`none`. Represent as a SERVED component (no method), do NOT
   generate a recipe. (The dish-list model already reserves a `served` status — § ref.)
2. **From-scratch guardrail (#3, Rasmus):** some dishes CAN be made but a reasonable person
   wouldn't here — croissant (12–24h proof), bread, stock. When ambiguous, ASK the user
   ("Use a ready croissant, or bake from scratch?") rather than silently generating a
   12-hour recipe. Needs an ambiguity signal + a clarify prompt in the meal flow.
3. **Compose robustness:** even once detection is in, parse/decompose should DEGRADE
   gracefully if one component is thin (skip/serve it) rather than failing the whole meal.
   The parser's strict title/ingredients/groups validation (import/route.ts:223) is the
   choke point.

### Priority
This is now the SHARPEST next design+build piece for the create flow — it's both the
served-not-made feature AND the fix for real compose failures (#1/#4). Design-led; settle
detect-vs-ask-vs-serve before building. Downstream of / defines `recipe.kind`.

### Also shipped this pass
- **#5 error visibility:** compose errors now surface in the FIXED bottom bar (red +
  warning icon), not buried below the fold at line 961. (status==='error' → bar shows the
  error text.) Small UX fix; done.

---

## 13. Served-not-made — two concrete mechanisms (Rasmus, captured for the build)

Two complementary mechanisms that together cover the served-not-made space and fix the
compose failures (§12). Both produce the same outcome: a dish becomes a SERVED / ready-made
component (no recipe generated) instead of being pushed through generate+parse.

### 13.1 The TIME guardrail — threshold + ask, threshold is a USER SETTING
- Define a reasonable maximum time a meal "should" take. If a from-scratch version of a
  dish would EXCEED that, ASK the user: use a ready one, or make from scratch?
- The threshold is a SETTING on the create screen, adjustable by the user BEFORE creating a
  meal (sensible default, e.g. ~60 min; user can raise it if they like long cooks).
- Effect: croissant (12–24h) > threshold → ask → user picks ready (served) or scratch
  (generate). A 2h stew is fine if the user set a high threshold. The USER owns the line —
  the system doesn't guess what's "too long."
- BUILD NOTE: needs a CHEAP time ESTIMATE at the RESOLUTION stage (before fully generating
  the dish), so the guardrail can fire before committing to a full recipe. The model can
  estimate "croissant from scratch ≈ many hours" cheaply. The estimate-then-maybe-ask step
  lives in the meal-resolution flow, not post-generation.

### 13.2 The COKE problem — curated "don't-make" list + user override
- No clean heuristic for "Coke isn't a recipe," so: a CURATED LIST of products normally
  BOUGHT not made (sodas, commercial beer/spirits, branded snacks, etc.).
- When a requested dish matches the list → mark it READY-MADE (served component), do NOT
  generate a recipe.
- ALLOW OVERRIDE: the user can still choose to make it (homemade cola, ginger beer) — the
  list is a smart default, not a lock.
- Claude can DRAFT the initial list as a build deliverable (sodas, commercial alcohol,
  confectionery/branded snacks, etc.), curatable later. Pairs with the catalogue/ingredient
  model (is_product items are natural candidates).

### 13.3 How they fit together
- Curated served-list → obvious off-the-shelf (Coke, beer) → default SERVED, allow override.
- Time-threshold-with-ask → "makeable but usually too long here" (croissant, stock, bread)
  → ASK, threshold is a user setting.
- Both → dish becomes a SERVED/ready-made component → not pushed through generation →
  fixes the §12 compose failures AND gives the right product behaviour.
- Still downstream of / defines `recipe.kind` (composed/simple/acquire/none): served =
  acquire/none. The dish-list model already reserves a `served` status for exactly this.
